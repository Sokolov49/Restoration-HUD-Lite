function MenuComponentManager:create_new_heists_gui(node)
	return
end